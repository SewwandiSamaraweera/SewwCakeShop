/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Thenali manathunga
 */
public class AddRecords {

    public void Records(String ID,String Category, String Name, String NICNumber,String ContactNumber,String Address, String Gender) {
        PreparedStatement pstmt = null;
        
        try {
            pstmt = DBConnection.getConnection().prepareStatement(
                    "INSERT INTO register (ID, Category, Name, NICNumber, ContactNumber,Address, Gender) VALUES (?, ?, ?, ?, ?, ?)");
            
            pstmt.setString(1, ID);
            pstmt.setString(2, Category);
            pstmt.setString(3, Name);
            pstmt.setString(4, NICNumber);
            pstmt.setString(5, Address);
            pstmt.setString(6, Gender);
            
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle or throw the exception as per your application's requirements
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
