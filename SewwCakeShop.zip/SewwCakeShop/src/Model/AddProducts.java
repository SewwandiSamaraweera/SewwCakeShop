/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import com.mysql.cj.xdevapi.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Thenali manathunga
 */
public class AddProducts {
    
    Statement stmt;
    
    public void addProduct(String ID, String Category, String Flavour, String Quantity, String Price) {
        String sql = "INSERT INTO Products (ID, Category, Flavour, Quantity, Price) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, ID);
            pstmt.setString(2, Category);
            pstmt.setString(3, Flavour);
            pstmt.setString(4, Quantity);
            pstmt.setString(5, Price);
            
            pstmt.executeUpdate();
            
            System.out.println("New product inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately, such as logging or showing an error message.
        }
    }

    public void Products(String ID, String Category, String Flavour, String Quantity, String Price) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

