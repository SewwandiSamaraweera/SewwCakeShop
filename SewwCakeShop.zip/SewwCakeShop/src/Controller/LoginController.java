/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import static Controller.LoginController.Login;
import View.MainMenu;
import Model.DBSearch;
import View.Login;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Thenali manathunga
 */
public class LoginController {
    public static void Login(String usName, String pass) {
        try {
            String username = null; // Changed variable name to camelCase
            String password = null; // Changed variable name to camelCase
            ResultSet rs = new DBSearch().searchLogin(usName);
            
            // Process the Query
            if (rs != null) {
                if (rs.next()) {
                    username = rs.getString("username");
                    password = rs.getString("password");
                    if (username != null && pass != null) {
                        if (password.equals(pass)) {
                            System.out.println("Login Successful");
                            Login.getFrames()[0].dispose();
                            new MainMenu().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid password", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "User not found", "Error", JOptionPane.ERROR_MESSAGE);
                }
                rs.close(); // Close the ResultSet
            } else {
                JOptionPane.showMessageDialog(null, "Database connection error", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "An unexpected error occurred", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
